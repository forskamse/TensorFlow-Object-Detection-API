# encoding:utf-8
# Copyright 2015 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

"""Simple image classification with Inception.

Run image classification with Inception trained on ImageNet 2012 Challenge data
set.

This program creates a graph from a saved GraphDef protocol buffer,
and runs inference on an input JPEG image. It outputs human readable
strings of the top 5 predictions along with their probabilities.

Change the --warm_up_image_file argument to specify any jpg image to warm-up 
the TensorFlow model.

Please see the tutorial and website for a detailed description of how
to use this script to perform image recognition.

https://tensorflow.org/tutorials/image_recognition/
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os.path
import re
import sys
import tarfile

import numpy as np
from six.moves import urllib
import tensorflow as tf

import time
#zhoubg 20180626
#from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
from http.server import BaseHTTPRequestHandler, HTTPServer
#from urlparse import parse_qsl
from urllib.parse import parse_qsl

####zhoubg 20180626
import os
import sys
import argparse
import cv2
from PIL import Image
from utils import label_map_util,visualization_utils

parser = argparse.ArgumentParser(description='Predict result using trained graph')
parser.add_argument('--model', help='Model path')
parser.add_argument('--labels', help='Label file path')
parser.add_argument('--warm_up_image', help='Warm up image path')
args = parser.parse_args()


sys.path.append('/home/pi/to/tensorflow/models') # point to your tensorflow dir
sys.path.append('/home/pi/to/tensorflow/models/slim') # point ot your slim dir

MAX_CLASSES = 1

# Size, in inches, of the output images.
IMAGE_SIZE = (12, 8)

class ObjectDetectionPredict():
    def __init__(self, model_path, labels_path):
        label_map = label_map_util.load_labelmap(labels_path)
        categories = label_map_util.convert_label_map_to_categories(
            label_map, max_num_classes=MAX_CLASSES, use_display_name=True)
        self.category_index = label_map_util.create_category_index(categories)
        self.load_tf_graph(model_path)

    def load_tf_graph(self, model_path):
        self.detection_graph = tf.Graph()
        with self.detection_graph.as_default():
            od_graph_def = tf.GraphDef()
            with tf.gfile.GFile(model_path, 'rb') as fid:
                serialized_graph = fid.read()
                od_graph_def.ParseFromString(serialized_graph)
                tf.import_graph_def(od_graph_def, name='')

            self.sess = tf.Session(graph=self.detection_graph)
        return 0


    def detect_objects(self, image_np):
        # Expand dimensions since the model expects images to have shape: [1, None, None, 3]
        image_np_expanded = np.expand_dims(image_np, axis=0)
        image_tensor = self.detection_graph.get_tensor_by_name('image_tensor:0')

        # Each box represents a part of the image where a particular object was detected.
        boxes = self.detection_graph.get_tensor_by_name('detection_boxes:0')

        # Each score represent the level of confidence for each of the objects.
        # Score is shown on the result image, together with the class label.
        scores = self.detection_graph.get_tensor_by_name('detection_scores:0')
        classes = self.detection_graph.get_tensor_by_name('detection_classes:0')
        num_detections = self.detection_graph.get_tensor_by_name('num_detections:0')

        # Actual detection.
        (boxes, scores, classes, num_detections) = self.sess.run(
            [boxes, scores, classes, num_detections],
            feed_dict={image_tensor: image_np_expanded})

        # Visualization of the results of a detection.
        image_np = visualization_utils.visualize_boxes_and_labels_on_image_array(
            image_np,
            np.squeeze(boxes),
            np.squeeze(classes).astype(np.int32),
            np.squeeze(scores),
            self.category_index,
            use_normalized_coordinates=True,
            max_boxes_to_draw=20,
            min_score_thresh=.1,
            line_thickness=4)
        return scores, classes, image_np


class MyRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # e.g. "/?image_path=/root/mobike.jpg"
        path = self.path
        # e.g. "/root/mobike.jpg"
        image_path = parse_qsl(path[2:])[0][1]
        print('-------------------------------------------')
        print('Will process image: {}\n'.format(image_path))
        start_time = time.time()
        image = Image.open(image_path)

        im_width, im_height = image.size
        image_np = np.array(image.getdata()).reshape((im_height, im_width, 3)).astype(np.uint8)
        print("Image loading used time:{} S".format(time.time() - start_time))
        start_time = time.time()
        scores, classes, image_np_with_labels = ObjectDetectionPredict_class.detect_objects(image_np)
        print("Prediction used time:{} S".format(time.time() - start_time))
        start_time = time.time()
        image_with_labels = Image.fromarray(image_np_with_labels)
        image_prefix,image_extend=os.path.splitext(image_path)
        image_with_labels.save("%s_predicted.jpg"%(image_prefix))
        print("Drawing used time:{} S".format(time.time() - start_time))
        print("\n".join("{0:<20s}: {1:.1f}%".format(ObjectDetectionPredict_class.category_index[c]['name'], s*100.) for (c, s) in zip(classes[0], scores[0])))
        print("Std output used time:{} S".format(time.time() - start_time))
        cv2.imshow("Prediction", image_np_with_labels)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        #返回信息尚未处理
        '''
        message_return_to_client = ''
        for one_line in prediction_result:
        message_return_to_client = message_return_to_client + one_line + '\n'

        # send response status code
        self.send_response(200)
        
        # send headers
        self.send_header('Content-type','text/html')
        self.end_headers()
        
        # send message back to client, write content as utf-8 data
        self.wfile.write(bytes(message_return_to_client, "utf8"))
        '''
        print('Process image {} done\n'.format(image_path))
        return 
    


def warm_up_model(warm_up_image):
  """Warm-up TensorFlow model, to increase the inference speed of each time."""

  # the image used to warm-up TensorFlow model
  '''if not tf.gfile.Exists(image):
    tf.logging.fatal('File does not exist %s', image)
  image_data = tf.gfile.FastGFile(image, 'rb').read()'''

  


  print('Warm-up starts')

  for i in range(1):
    ###testing 20180712
    # j=i
    # j=j+4
    # warm_up_image = '/home/pi/pig_test/'+str(j)+'.jpg'
    ###end of testing
    
    print('Warm-up for time {}'.format(i+1))
    start_time = time.time()
    image = Image.open(warm_up_image)     
    (im_width, im_height) = image.size
    image_np = np.array(image.getdata()).reshape((im_height, im_width, 3)).astype(np.uint8)
    print("Image loading used time:{} S".format(time.time() - start_time))
    start_time = time.time()
    scores, classes, image_np_with_labels = ObjectDetectionPredict_class.detect_objects(image_np)
    print("Prediction used time:{} S".format(time.time() - start_time))
    start_time = time.time()
    image_with_labels = Image.fromarray(image_np_with_labels)
    image_prefix,image_extend=os.path.splitext(warm_up_image)
    image_with_labels.save("%s_predicted.jpg"%(image_prefix))
    #print("\n".join("{0:<20s}: {1:.1f}%".format(ObjectDetectionPredict_class.category_index[c]['name'], s*100.) for (c, s) in zip(classes[0], scores[0])))
    print("Drawing used time:{} S".format(time.time() - start_time))
    # cv2.imshow("Prediction", image_np_with_labels)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
  print('Warm-up finished')

def main():
    global ObjectDetectionPredict_class
    ObjectDetectionPredict_class = ObjectDetectionPredict(args.model, args.labels)
    warm_up_model(args.warm_up_image)
    server_address = ('127.0.0.1', 8080)
    httpd = HTTPServer(server_address, MyRequestHandler)
    print('TensorFlow service started')
    httpd.serve_forever()


if __name__ == '__main__':
  main()
